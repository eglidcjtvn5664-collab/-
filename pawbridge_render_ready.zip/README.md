# PAWBRIDGE｜寵物國際貿易會員系統（源碼）

這是 FastAPI + SQLAlchemy 的**可部署起始版**，包含公司官網、企業管理員、會員驗證及按客戶隔離的商品與銷售訂單。沒有預先建立任何假的會員／訂單／捐款資料。

## 本機執行

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
export ADMIN_EMAIL='admin@example.com'
export ADMIN_PASSWORD='自行設定至少12字元強密碼'
python -m app.bootstrap_admin
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

開啟 `http://127.0.0.1:8000` 瀏覽官網、`/login` 登入會員中心。管理員先新增合作客戶，再新增所屬會員、商品與訂單。

## 上線前必做

1. 選擇可執行 Python 後端的平台（例如 Render）。**靜態網站服務不能直接執行完整會員系統**。
2. 設定 `ENVIRONMENT=production`、`COOKIE_SECURE=true`、`APP_ORIGIN=https://你的網址`、`ALLOWED_HOSTS=你的網域`。
3. 使用正式 PostgreSQL 設定 `DATABASE_URL=postgresql+psycopg://...`，啟用備份、TLS 連線及備援。
4. `UPLOAD_DIR` 放於持久磁碟或改為安全的物件儲存。圖片資料夾不得放在每次部署會被清空的暫存空間。
5. 先以環境變數建立管理員帳號，**不要把密碼放入程式或 Git**。
6. 為正式網站設定真實的公司名稱、地址、合法聯絡窗口、隱私權條款與服務條款；現有 PAWBRIDGE 是示範品牌名稱。
7. 資安驗證（授權、登入限制、CSRF、防 SQL injection、圖片上傳掃描、備份還原與外部滲透測試）通過後再開放真實客戶。此程式碼尚非完成第三方資安稽核的正式產品。
8. 目前是**管理員手動建立訂單**，尚未串接金流、物流或電商平台。每個會員只會看到屬於自己客戶的商品與訂單，並非即時電商自動同步。

## 模組

- `/` 官網，含寫實寵物素材、商品分類、公司歷程、公益記錄（只公開已核實內容）
- `/login` 會員登入（Argon2 雜湊、HttpOnly Session Cookie）
- `/member` 會員商品、訂單、銷售報表、密碼修改
- `/api/admin/...` 會員／客戶／商品／訂單／公司歷程／公益／操作日誌
- 圖片上傳：僅管理員，限制 3MB／驗證格式／重新編碼 WebP；圖片存取依會員隔離

**說明：此源碼下載後需部署到 Python 伺服器，不能像先前的 HTML 檔直接雙擊執行會員功能。**
