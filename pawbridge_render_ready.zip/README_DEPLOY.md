# PAWBRIDGE 發佈到 Render 的說明

這是可部署的 Python FastAPI 會員系統來源碼。下載 ZIP、解壓縮，把這個資料夾**裡面的所有檔案**上傳到 GitHub 私人儲存庫根目錄（可看到 `requirements.txt`、`render.yaml`、`app/`）。

## Render 最簡單的測試部署流程

1. 到 https://github.com/new 建立 **Private** 儲存庫，把解壓縮內容上傳。
2. 到 https://dashboard.render.com ，New > Postgres 建立資料庫；正式營運請使用付費方案，確保備份、可持續保存資料。免費資料庫 30 天到期，只適合測試。
3. 在資料庫 Connect 複製 **Internal Database URL**，保密勿貼公開聊天或 GitHub。
4. Render New > Blueprint > Connect GitHub repo。選擇本儲存庫，畫面會偵測 `render.yaml`。
5. 建立 Blueprint 時輸入 `DATABASE_URL`（上步取得的 Postgres Internal Database URL）、`ADMIN_EMAIL` 和長度至少 12 字元的 `ADMIN_PASSWORD`（不要使用 123456，且不要放到 GitHub）。
6. Render 自動建置後打開服務頁面的 `https://...onrender.com` 網址。首頁 `/`，登入頁 `/login`。若要自訂域名，到 Render 設定 Custom Domains，並更新 `APP_ORIGIN`、`ALLOWED_HOSTS`。
7. 登入管理員建立合作客戶、會員、商品與訂單；沒有訂單時不會假顯示銷售額。

## 源碼調整
- 接受 Render Postgres 的 `postgresql://` / `postgres://` 連線字串並使用 psycopg3。
- 自動使用 Render 提供的官方 HTTPS 網址和主機名稱，避免初次部署因缺少安全主機參數而無法啟動。設置自訂網域時請明確配置 `APP_ORIGIN`、`ALLOWED_HOSTS`。
- `render.yaml` 建立 Web Service，**不會自動建立資料庫**，請先建立 DB。此設定使用免費 Web Service，僅限網站預覽與測試。

## 正式對外使用前必做
- 免費 Web Service 不保存重啟/部署後的本機上傳檔案。若要上傳商品圖片，需改為持久物件儲存或使用付費磁碟 + 設定 `UPLOAD_DIR`；不可依賴暫存硬碟。
- 管理好管理員密碼、資料庫憑證、權限、備份，完成滲透測試、安全審查、隱私權政策。
- 目前銷售數字來自管理員建立的訂單資料，不是與實際電商平台同步。若要自動更新銷售額，需再串接金流、物流或電商平台 API。
- 不要把未經核實的捐款金額、公司歷程或商品宣稱放在公開網站上。
