import os, sys
from argon2 import PasswordHasher
from .models import User
from .settings import init_db,SessionLocal

def main():
    email=os.getenv('ADMIN_EMAIL','').strip().lower()
    password=os.getenv('ADMIN_PASSWORD','')
    name=os.getenv('ADMIN_NAME','系統管理員')
    if not email or '@' not in email or len(password)<12:
        print('請先設定 ADMIN_EMAIL 和長度至少 12 字元的 ADMIN_PASSWORD 環境變數',file=sys.stderr);return 1
    init_db()
    with SessionLocal() as db:
        if db.query(User).filter(User.email==email).first():
            print('管理員帳號已存在，未改寫密碼'); return 0
        db.add(User(email=email,name=name,password_hash=PasswordHasher().hash(password),role='admin',active=True))
        db.commit()
    print('管理員已建立：',email)
    return 0
if __name__=='__main__':sys.exit(main())
