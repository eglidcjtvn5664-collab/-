"""PAWBRIDGE: server-side authenticated pet trade member portal.
No demo credentials or sales are pre-seeded. Customer isolation is enforced on the server.
"""
from __future__ import annotations
import hashlib, io, os, re, secrets
from datetime import datetime, timedelta, timezone
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Annotated, Literal
from urllib.parse import urlparse

from argon2 import PasswordHasher, exceptions as argon_errors
from fastapi import FastAPI, Depends, HTTPException, Request, Response, UploadFile, File, Header
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from pydantic import BaseModel, Field, EmailStr, ConfigDict, field_validator
from sqlalchemy import select, update, func, delete
from sqlalchemy.orm import Session
from PIL import Image, UnidentifiedImageError

from .models import Customer, User, SessionToken, LoginAttempt, Product, Order, Timeline, Donation, AuditLog, utcnow
from .settings import SessionLocal, get_db, init_db, UPLOAD_DIR, COOKIE_SECURE, APP_ORIGIN, ALLOWED_HOSTS, IS_PRODUCTION

STATIC=Path(__file__).resolve().parent/'static'
TEMPLATES=Path(__file__).resolve().parent/'templates'
ph=PasswordHasher(time_cost=3,memory_cost=65536,parallelism=2)
PAID={'已付款','配送中','已完成'}
STATES={'待付款','已付款','配送中','已完成','已取消','已退款'}

@asynccontextmanager
async def lifespan(app):
    if IS_PRODUCTION and (not COOKIE_SECURE or not APP_ORIGIN or ALLOWED_HOSTS==['*']):
        raise RuntimeError('正式環境必須設定 COOKIE_SECURE=true, APP_ORIGIN, ALLOWED_HOSTS')
    init_db()
    yield

app=FastAPI(title='PAWBRIDGE 會員銷售管理',docs_url=None,redoc_url=None,openapi_url=None,lifespan=lifespan)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=ALLOWED_HOSTS)
app.mount('/static', StaticFiles(directory=str(STATIC)),name='static')

@app.middleware('http')
async def security_headers(request:Request,call_next):
    result=await call_next(request)
    result.headers['X-Content-Type-Options']='nosniff'
    result.headers['Referrer-Policy']='strict-origin-when-cross-origin'
    result.headers['X-Frame-Options']='DENY'
    result.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
    result.headers['Content-Security-Policy']="default-src 'self'; img-src 'self' data:; script-src 'self'; style-src 'self' 'unsafe-inline'; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'"
    if request.url.path.startswith(('/api/','/member','/login')):result.headers['Cache-Control']='no-store, private'
    if COOKIE_SECURE:result.headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains'
    return result

@app.get('/',response_class=HTMLResponse)
def home():return (TEMPLATES/'index.html').read_text(encoding='utf-8')

@app.get('/login',response_class=HTMLResponse)
def login_page():return (TEMPLATES/'login.html').read_text(encoding='utf-8')

@app.get('/member',response_class=HTMLResponse)
def portal_page():return (TEMPLATES/'member.html').read_text(encoding='utf-8')

@app.get('/health')
def health():return {'ok':True}

def emailnorm(s:str):return s.strip().lower()
def dt(v:datetime):return v.isoformat() if v else None
def digest(s:str):return hashlib.sha256(s.encode('utf-8')).hexdigest()
def fail(status=400,message='請求無法處理'):
    raise HTTPException(status_code=status,detail=message)

def session_auth(request:Request,db:Session=Depends(get_db)):
    token=request.cookies.get('pb_session','')
    if not token:return fail(401,'請先登入')
    row=db.scalar(select(SessionToken).where(SessionToken.token_hash==digest(token)))
    if not row:return fail(401,'登入已失效，請重新登入')
    until=row.expires_at.replace(tzinfo=timezone.utc) if row.expires_at.tzinfo is None else row.expires_at
    if until<=utcnow():
        db.delete(row); db.commit(); return fail(401,'登入已逾時，請重新登入')
    user=db.get(User,row.user_id)
    if not user or not user.active or (user.role=='member' and not user.customer_id):return fail(403,'帳號目前無法使用')
    return (user,row)

def require_auth(auth=Depends(session_auth)):
    return auth

def require_write(request:Request,auth=Depends(require_auth)):
    session=auth[1]
    if not secrets.compare_digest(request.headers.get('X-CSRF-Token',''),session.csrf_token):return fail(403,'安全驗證失敗，請重新整理頁面')
    origin=request.headers.get('Origin','')
    if origin:
        expected=APP_ORIGIN or str(request.base_url).rstrip('/')
        if origin.rstrip('/') != expected:return fail(403,'來源驗證失敗')
    return auth

def require_admin(auth=Depends(require_write)):
    if auth[0].role!='admin':return fail(403,'只有管理員可以操作')
    return auth

def require_admin_read(auth=Depends(require_auth)):
    if auth[0].role!='admin':return fail(403,'只有管理員可以查看')
    return auth

def log(db:Session,user:User,action:str,target:str,details:str=''):
    db.add(AuditLog(user_id=user.id,action=action,target=target,details=details[:1000]))

class LoginIn(BaseModel):
    email: EmailStr
    password: str=Field(min_length=1,max_length=512)

@app.post('/api/auth/login')
def login(payload:LoginIn,request:Request,response:Response,db:Session=Depends(get_db)):
    email=emailnorm(str(payload.email))
    ip=request.client.host if request.client else 'unknown'
    # Database-backed rolling-window throttling (by username and IP).
    subjects=[digest('email:'+email),digest('ip:'+ip)]
    window=utcnow()-timedelta(minutes=15)
    for subject in subjects:
        n=db.scalar(select(func.count()).select_from(LoginAttempt).where(LoginAttempt.subject_hash==subject,LoginAttempt.created_at>=window,LoginAttempt.succeeded==False))
        if n>=8:return fail(429,'登入嘗試過多，請稍後再試')
    user=db.scalar(select(User).where(User.email==email,User.active==True))
    matched=False
    if user:
        try: matched=ph.verify(user.password_hash,payload.password)
        except (argon_errors.VerifyMismatchError,argon_errors.VerificationError,argon_errors.InvalidHashError):pass
    if not matched:
        for subject in subjects:db.add(LoginAttempt(subject_hash=subject,succeeded=False))
        db.commit();return fail(401,'帳號或密碼不正確')
    # Remove recent failures after successful authentication.
    db.execute(delete(LoginAttempt).where(LoginAttempt.subject_hash.in_(subjects)))
    raw=secrets.token_urlsafe(48)
    csrf=secrets.token_urlsafe(32)
    db.add(SessionToken(token_hash=digest(raw),user_id=user.id,csrf_token=csrf,expires_at=utcnow()+timedelta(hours=12)))
    db.commit()
    response.set_cookie('pb_session',raw,httponly=True,secure=COOKIE_SECURE,samesite='lax',max_age=12*3600,path='/')
    return {'ok':True,'role':user.role,'csrf_token':csrf}

@app.get('/api/me')
def me(auth=Depends(require_auth),db:Session=Depends(get_db)):
    u,s=auth
    customer=db.get(Customer,u.customer_id) if u.customer_id else None
    return {'id':u.id,'name':u.name,'email':u.email,'role':u.role,'customer_id':u.customer_id,
            'customer_name':customer.name if customer else None,'csrf_token':s.csrf_token}

@app.post('/api/auth/logout')
def logout(response:Response,auth=Depends(require_write),db:Session=Depends(get_db)):
    db.delete(auth[1]);db.commit();response.delete_cookie('pb_session',path='/')
    return {'ok':True}

class PasswordChange(BaseModel):
    old_password:str=Field(min_length=1,max_length=512)
    new_password:str=Field(min_length=12,max_length=256)

@app.post('/api/auth/change-password')
def change_password(payload:PasswordChange,auth=Depends(require_write),db:Session=Depends(get_db)):
    user=auth[0]
    try:ok=ph.verify(user.password_hash,payload.old_password)
    except (argon_errors.VerifyMismatchError,argon_errors.VerificationError,argon_errors.InvalidHashError):ok=False
    if not ok:return fail(400,'目前密碼不正確')
    if payload.old_password==payload.new_password:return fail(400,'新密碼不可與舊密碼相同')
    user.password_hash=ph.hash(payload.new_password)
    db.execute(delete(SessionToken).where(SessionToken.user_id==user.id,SessionToken.id!=auth[1].id))
    log(db,user,'change-password',f'user:{user.id}')
    db.commit();return {'ok':True}

def product_dict(p:Product):
    return {'id':p.id,'sku':p.sku,'name':p.name,'category':p.category,'customer_id':p.customer_id,
            'price_cents':p.price_cents,'stock':p.stock,'active':p.active,
            'image_url':f'/api/products/{p.id}/image' if p.image_filename else '/static/assets/collection-04.webp'}

def order_dict(o:Order,prod:Product|None):
    return {'id':o.id,'order_no':o.order_no,'customer_id':o.customer_id,'product_id':o.product_id,
            'product_name':prod.name if prod else '商品已移除','quantity':o.quantity,
            'unit_price_cents':o.unit_price_cents,'total_cents':o.quantity*o.unit_price_cents,
            'status':o.status,'created_at':dt(o.created_at)}

def customer_filter(stmt,model,auth):
    u=auth[0]
    if u.role=='admin':return stmt
    return stmt.where(model.customer_id==u.customer_id)

@app.get('/api/products')
def list_products(auth=Depends(require_auth),db:Session=Depends(get_db)):
    q=customer_filter(select(Product).order_by(Product.id.desc()),Product,auth)
    return {'items':[product_dict(p) for p in db.scalars(q.limit(500)).all()]}

@app.get('/api/products/{product_id}/image')
def product_image(product_id:int,auth=Depends(require_auth),db:Session=Depends(get_db)):
    p=db.get(Product,product_id)
    if not p or (auth[0].role!='admin' and p.customer_id!=auth[0].customer_id):return fail(404,'找不到圖片')
    if not p.image_filename:return FileResponse(STATIC/'assets'/'collection-04.webp',media_type='image/webp')
    path=UPLOAD_DIR/p.image_filename
    if not path.exists():return fail(404,'圖片不存在')
    return FileResponse(path,media_type='image/webp',headers={'Cache-Control':'private, no-store'})

@app.get('/api/orders')
def list_orders(auth=Depends(require_auth),db:Session=Depends(get_db),page:int=1):
    if page<1 or page>10000:return fail(422,'頁碼錯誤')
    q=customer_filter(select(Order).order_by(Order.created_at.desc(),Order.id.desc()),Order,auth)
    count=db.scalar(select(func.count()).select_from(q.subquery()))
    orders=db.scalars(q.offset((page-1)*50).limit(50)).all()
    products={p.id:p for p in db.scalars(select(Product).where(Product.id.in_([x.product_id for x in orders]))).all()} if orders else {}
    return {'items':[order_dict(o,products.get(o.product_id)) for o in orders],'page':page,'total':count,'page_size':50}

@app.get('/api/dashboard')
def dashboard(auth=Depends(require_auth),db:Session=Depends(get_db)):
    q=customer_filter(select(Order),Order,auth)
    rows=db.scalars(q).all()
    sold=[o for o in rows if o.status in PAID]
    total=sum(o.quantity*o.unit_price_cents for o in sold)
    qty=sum(o.quantity for o in sold)
    now=utcnow()
    monthly={}
    for o in sold:
        key=o.created_at.strftime('%Y-%m')
        monthly[key]=monthly.get(key,0)+o.quantity*o.unit_price_cents
    months=[]
    for d in range(5,-1,-1):
        year=now.year+(now.month-1-d)//12
        month=(now.month-1-d)%12+1
        key=f'{year:04d}-{month:02d}'
        months.append({'month':key,'amount_cents':monthly.get(key,0)})
    return {'products':db.scalar(select(func.count()).select_from(customer_filter(select(Product),Product,auth).subquery())),
            'orders':len(rows),'sold_quantity':qty,'sales_cents':total,
            'pending_orders':sum(o.status=='待付款' for o in rows),
            'monthly_sales':months,
            'note':'銷售金額為已付款／配送中／已完成訂單總額，未扣除運費、手續費與退貨成本；資料均來自系統正式訂單。'}

class CustomerIn(BaseModel):
    name:str=Field(min_length=2,max_length=150)
    code:str=Field(min_length=2,max_length=40,pattern=r'^[A-Za-z0-9_-]+$')

@app.get('/api/admin/customers')
def customers(auth=Depends(require_admin_read),db:Session=Depends(get_db)):
    return {'items':[{'id':c.id,'name':c.name,'code':c.code} for c in db.scalars(select(Customer).order_by(Customer.id.desc())).all()]}

@app.post('/api/admin/customers',status_code=201)
def create_customer(payload:CustomerIn,auth=Depends(require_admin),db:Session=Depends(get_db)):
    if db.scalar(select(Customer).where(Customer.code==payload.code)):return fail(409,'客戶代碼已存在')
    row=Customer(name=payload.name.strip(),code=payload.code.strip())
    db.add(row);db.flush();log(db,auth[0],'create-customer',f'customer:{row.id}')
    db.commit();return {'id':row.id}

class UserIn(BaseModel):
    email:EmailStr
    name:str=Field(min_length=2,max_length=120)
    password:str=Field(min_length=12,max_length=256)
    customer_id:int

@app.get('/api/admin/users')
def list_users(auth=Depends(require_admin_read),db:Session=Depends(get_db)):
    return {'items':[{'id':u.id,'email':u.email,'name':u.name,'role':u.role,'customer_id':u.customer_id,'active':u.active}
                     for u in db.scalars(select(User).order_by(User.id.desc())).all()]}

@app.post('/api/admin/users',status_code=201)
def create_member(payload:UserIn,auth=Depends(require_admin),db:Session=Depends(get_db)):
    email=emailnorm(str(payload.email))
    if db.scalar(select(User).where(User.email==email)):return fail(409,'電子信箱已存在')
    if not db.get(Customer,payload.customer_id):return fail(404,'找不到客戶')
    row=User(email=email,name=payload.name.strip(),password_hash=ph.hash(payload.password),customer_id=payload.customer_id,role='member')
    db.add(row);db.flush();log(db,auth[0],'create-member',f'user:{row.id}')
    db.commit();return {'id':row.id}

class MemberUpdate(BaseModel):
    active:bool|None=None
    new_password:str|None=Field(default=None,min_length=12,max_length=256)

@app.patch('/api/admin/users/{user_id}')
def update_member(user_id:int,payload:MemberUpdate,auth=Depends(require_admin),db:Session=Depends(get_db)):
    target=db.get(User,user_id)
    if not target or target.role=='admin':return fail(404,'找不到會員')
    if payload.active is not None:target.active=payload.active
    if payload.new_password:
        target.password_hash=ph.hash(payload.new_password)
        db.execute(delete(SessionToken).where(SessionToken.user_id==target.id))
    log(db,auth[0],'update-member',f'user:{target.id}')
    db.commit();return {'ok':True}

class ProductIn(BaseModel):
    sku:str=Field(min_length=2,max_length=64,pattern=r'^[A-Za-z0-9_.-]+$')
    customer_id:int
    name:str=Field(min_length=2,max_length=160)
    category:str=Field(default='寵物用品',min_length=1,max_length=80)
    price_cents:int=Field(ge=0,le=1000000000)
    stock:int=Field(ge=0,le=100000000)
    active:bool=True

@app.post('/api/admin/products',status_code=201)
def create_product(payload:ProductIn,auth=Depends(require_admin),db:Session=Depends(get_db)):
    if not db.get(Customer,payload.customer_id):return fail(404,'找不到客戶')
    if db.scalar(select(Product).where(Product.sku==payload.sku)):return fail(409,'商品編號已存在')
    row=Product(**payload.model_dump());db.add(row);db.flush()
    log(db,auth[0],'create-product',f'product:{row.id}')
    db.commit();return product_dict(row)

class ProductUpdate(BaseModel):
    name:str|None=Field(default=None,min_length=2,max_length=160)
    category:str|None=Field(default=None,min_length=1,max_length=80)
    price_cents:int|None=Field(default=None,ge=0,le=1000000000)
    stock:int|None=Field(default=None,ge=0,le=100000000)
    active:bool|None=None

@app.patch('/api/admin/products/{product_id}')
def update_product(product_id:int,payload:ProductUpdate,auth=Depends(require_admin),db:Session=Depends(get_db)):
    row=db.get(Product,product_id)
    if not row:return fail(404,'找不到商品')
    for k,v in payload.model_dump(exclude_unset=True).items():setattr(row,k,v)
    log(db,auth[0],'update-product',f'product:{row.id}')
    db.commit();return product_dict(row)

@app.post('/api/admin/products/{product_id}/image')
async def upload_product_image(product_id:int,file:UploadFile=File(...),auth=Depends(require_admin),db:Session=Depends(get_db)):
    p=db.get(Product,product_id)
    if not p:return fail(404,'找不到商品')
    contents=await file.read(3*1024*1024+1)
    if len(contents)>3*1024*1024:return fail(413,'圖片不可超過 3MB')
    try:
        with Image.open(io.BytesIO(contents)) as im:
            im.verify()
        with Image.open(io.BytesIO(contents)) as im:
            if im.format not in ('PNG','JPEG','WEBP'):return fail(415,'僅支援 PNG、JPEG、WEBP')
            if im.width*im.height>20_000_000:return fail(413,'圖片尺寸過大')
            im.thumbnail((1600,1600))
            if im.mode!='RGB':im=im.convert('RGB')
            name=secrets.token_hex(24)+'.webp'
            im.save(UPLOAD_DIR/name,'WEBP',quality=83,method=5)
    except (UnidentifiedImageError,OSError,ValueError):return fail(415,'圖片格式無法讀取')
    previous=p.image_filename
    p.image_filename=name
    log(db,auth[0],'upload-product-image',f'product:{p.id}')
    db.commit()
    if previous:
        try:(UPLOAD_DIR/previous).unlink(missing_ok=True)
        except OSError:pass
    return {'ok':True,'image_url':f'/api/products/{p.id}/image'}

class OrderIn(BaseModel):
    order_no:str=Field(min_length=3,max_length=50,pattern=r'^[A-Za-z0-9_-]+$')
    customer_id:int
    product_id:int
    quantity:int=Field(ge=1,le=100000)
    status:Literal['待付款','已付款','配送中','已完成','已取消','已退款']='待付款'


def apply_inventory(db:Session,product:Product,order:Order,new_status:str):
    deduct=new_status in PAID
    if deduct and not order.stock_deducted:
        # Conditional SQL update prevents overselling under simultaneous admin writes.
        r=db.execute(update(Product).where(Product.id==product.id,Product.stock>=order.quantity)
                     .values(stock=Product.stock-order.quantity))
        if r.rowcount!=1:return fail(409,'庫存不足，無法標記為已售出')
        order.stock_deducted=True
    if not deduct and order.stock_deducted:
        db.execute(update(Product).where(Product.id==product.id).values(stock=Product.stock+order.quantity))
        order.stock_deducted=False
    order.status=new_status

@app.post('/api/admin/orders',status_code=201)
def create_order(payload:OrderIn,auth=Depends(require_admin),db:Session=Depends(get_db)):
    if db.scalar(select(Order).where(Order.order_no==payload.order_no)):return fail(409,'訂單編號已存在')
    p=db.get(Product,payload.product_id)
    if not p or p.customer_id!=payload.customer_id or not p.active:return fail(422,'商品不屬於該客戶或已停用')
    o=Order(order_no=payload.order_no,customer_id=payload.customer_id,product_id=p.id,
            quantity=payload.quantity,unit_price_cents=p.price_cents,status='待付款')
    db.add(o);db.flush()
    apply_inventory(db,p,o,payload.status)
    log(db,auth[0],'create-order',f'order:{o.id}',f'status:{payload.status}')
    db.commit();return order_dict(o,p)

class OrderStatus(BaseModel):
    status:Literal['待付款','已付款','配送中','已完成','已取消','已退款']

@app.patch('/api/admin/orders/{order_id}')
def update_order(order_id:int,payload:OrderStatus,auth=Depends(require_admin),db:Session=Depends(get_db)):
    o=db.get(Order,order_id)
    if not o:return fail(404,'找不到訂單')
    p=db.get(Product,o.product_id)
    before=o.status
    apply_inventory(db,p,o,payload.status)
    log(db,auth[0],'update-order',f'order:{o.id}',f'{before} -> {o.status}')
    db.commit();return order_dict(o,p)

class TimelineIn(BaseModel):
    happened_on:str=Field(pattern=r'^\d{4}-\d{2}-\d{2}$')
    title:str=Field(min_length=2,max_length=120)
    description:str=Field(default='',max_length=1500)
    published:bool=False

class DonationIn(BaseModel):
    happened_on:str=Field(pattern=r'^\d{4}-\d{2}-\d{2}$')
    recipient:str=Field(min_length=2,max_length=160)
    description:str=Field(default='',max_length=2000)
    amount_cents:int|None=Field(default=None,ge=0,le=100000000000)
    evidence_url:str=Field(default='',max_length=550)
    published:bool=False
    @field_validator('evidence_url')
    @classmethod
    def validate_url(cls,v):
        if not v:return v
        p=urlparse(v)
        if p.scheme!='https' or not p.netloc or p.username or p.password:raise ValueError('證明連結須為 HTTPS 網址')
        return v

@app.get('/api/public/company')
def public_company(db:Session=Depends(get_db)):
    tls=db.scalars(select(Timeline).where(Timeline.published==True).order_by(Timeline.happened_on.desc())).all()
    ds=db.scalars(select(Donation).where(Donation.published==True).order_by(Donation.happened_on.desc())).all()
    return {'timeline':[{'id':t.id,'date':t.happened_on,'title':t.title,'description':t.description} for t in tls],
            'donations':[{'id':d.id,'date':d.happened_on,'recipient':d.recipient,'description':d.description,
                          'amount_cents':d.amount_cents,'evidence_url':d.evidence_url} for d in ds]}

@app.get('/api/admin/company')
def company_admin(auth=Depends(require_admin_read),db:Session=Depends(get_db)):
    return {'timeline':[{'id':t.id,'date':t.happened_on,'title':t.title,'description':t.description,'published':t.published}
                        for t in db.scalars(select(Timeline).order_by(Timeline.happened_on.desc())).all()],
            'donations':[{'id':d.id,'date':d.happened_on,'recipient':d.recipient,'description':d.description,
                          'amount_cents':d.amount_cents,'evidence_url':d.evidence_url,'published':d.published}
                         for d in db.scalars(select(Donation).order_by(Donation.happened_on.desc())).all()]}

@app.post('/api/admin/timeline',status_code=201)
def create_timeline(payload:TimelineIn,auth=Depends(require_admin),db:Session=Depends(get_db)):
    t=Timeline(**{**payload.model_dump(),'happened_on':payload.happened_on});db.add(t);db.flush()
    log(db,auth[0],'create-timeline',f'timeline:{t.id}')
    db.commit();return {'id':t.id}

@app.post('/api/admin/donations',status_code=201)
def create_donation(payload:DonationIn,auth=Depends(require_admin),db:Session=Depends(get_db)):
    if payload.published and not payload.evidence_url:return fail(422,'公開捐款紀錄前，請提供有效的捐贈證明連結')
    d=Donation(**{**payload.model_dump(),'happened_on':payload.happened_on});db.add(d);db.flush()
    log(db,auth[0],'create-donation',f'donation:{d.id}')
    db.commit();return {'id':d.id}

class PublishIn(BaseModel):published:bool
@app.patch('/api/admin/timeline/{item_id}/publish')
def publish_timeline(item_id:int,payload:PublishIn,auth=Depends(require_admin),db:Session=Depends(get_db)):
    t=db.get(Timeline,item_id)
    if not t:return fail(404,'找不到歷程')
    t.published=payload.published;log(db,auth[0],'publish-timeline',f'timeline:{t.id}',str(t.published));db.commit();return {'ok':True}

@app.patch('/api/admin/donations/{item_id}/publish')
def publish_donation(item_id:int,payload:PublishIn,auth=Depends(require_admin),db:Session=Depends(get_db)):
    d=db.get(Donation,item_id)
    if not d:return fail(404,'找不到公益紀錄')
    if payload.published and not d.evidence_url:return fail(422,'必須先提供捐贈證明連結')
    d.published=payload.published;log(db,auth[0],'publish-donation',f'donation:{d.id}',str(d.published));db.commit();return {'ok':True}

@app.get('/api/admin/audit')
def audit(auth=Depends(require_admin_read),db:Session=Depends(get_db)):
    rows=db.scalars(select(AuditLog).order_by(AuditLog.id.desc()).limit(100)).all()
    return {'items':[{'id':a.id,'action':a.action,'target':a.target,'details':a.details,'date':dt(a.created_at)} for a in rows]}
