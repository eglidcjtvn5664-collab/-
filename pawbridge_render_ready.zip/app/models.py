from datetime import datetime, timezone
from sqlalchemy import Integer, String, DateTime, ForeignKey, Boolean, Text, Index
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

def utcnow(): return datetime.now(timezone.utc)
class Base(DeclarativeBase): pass

class Customer(Base):
    __tablename__='customers'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    name:Mapped[str]=mapped_column(String(150),nullable=False)
    code:Mapped[str]=mapped_column(String(40),unique=True,nullable=False,index=True)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)

class User(Base):
    __tablename__='users'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    email:Mapped[str]=mapped_column(String(255),unique=True,index=True,nullable=False)
    name:Mapped[str]=mapped_column(String(120),nullable=False)
    password_hash:Mapped[str]=mapped_column(String(300),nullable=False)
    role:Mapped[str]=mapped_column(String(12),nullable=False,default='member')
    customer_id:Mapped[int|None]=mapped_column(ForeignKey('customers.id'),nullable=True,index=True)
    active:Mapped[bool]=mapped_column(Boolean,default=True,nullable=False)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)

class SessionToken(Base):
    __tablename__='session_tokens'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    token_hash:Mapped[str]=mapped_column(String(64),unique=True,index=True,nullable=False)
    user_id:Mapped[int]=mapped_column(ForeignKey('users.id'),nullable=False,index=True)
    csrf_token:Mapped[str]=mapped_column(String(64),nullable=False)
    expires_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)

class LoginAttempt(Base):
    __tablename__='login_attempts'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    subject_hash:Mapped[str]=mapped_column(String(64),nullable=False,index=True)
    succeeded:Mapped[bool]=mapped_column(Boolean,nullable=False,default=False)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)

class Product(Base):
    __tablename__='products'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    sku:Mapped[str]=mapped_column(String(64),unique=True,index=True,nullable=False)
    customer_id:Mapped[int]=mapped_column(ForeignKey('customers.id'),nullable=False,index=True)
    name:Mapped[str]=mapped_column(String(160),nullable=False)
    category:Mapped[str]=mapped_column(String(80),nullable=False,default='寵物用品')
    price_cents:Mapped[int]=mapped_column(Integer,nullable=False)
    stock:Mapped[int]=mapped_column(Integer,nullable=False,default=0)
    active:Mapped[bool]=mapped_column(Boolean,default=True,nullable=False)
    image_filename:Mapped[str|None]=mapped_column(String(90),nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)

class Order(Base):
    __tablename__='orders'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    order_no:Mapped[str]=mapped_column(String(50),unique=True,index=True,nullable=False)
    customer_id:Mapped[int]=mapped_column(ForeignKey('customers.id'),nullable=False,index=True)
    product_id:Mapped[int]=mapped_column(ForeignKey('products.id'),nullable=False,index=True)
    quantity:Mapped[int]=mapped_column(Integer,nullable=False)
    unit_price_cents:Mapped[int]=mapped_column(Integer,nullable=False)
    status:Mapped[str]=mapped_column(String(20),default='待付款',nullable=False)
    stock_deducted:Mapped[bool]=mapped_column(Boolean,default=False,nullable=False)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)

class Timeline(Base):
    __tablename__='timeline'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    happened_on:Mapped[str]=mapped_column(String(10),nullable=False)
    title:Mapped[str]=mapped_column(String(120),nullable=False)
    description:Mapped[str]=mapped_column(Text,nullable=False,default='')
    published:Mapped[bool]=mapped_column(Boolean,default=False,nullable=False)

class Donation(Base):
    __tablename__='donations'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    happened_on:Mapped[str]=mapped_column(String(10),nullable=False)
    recipient:Mapped[str]=mapped_column(String(160),nullable=False)
    description:Mapped[str]=mapped_column(Text,nullable=False,default='')
    amount_cents:Mapped[int|None]=mapped_column(Integer,nullable=True)
    evidence_url:Mapped[str]=mapped_column(String(550),nullable=False,default='')
    published:Mapped[bool]=mapped_column(Boolean,default=False,nullable=False)

class AuditLog(Base):
    __tablename__='audit_logs'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    user_id:Mapped[int|None]=mapped_column(ForeignKey('users.id'),nullable=True)
    action:Mapped[str]=mapped_column(String(70),nullable=False)
    target:Mapped[str]=mapped_column(String(140),nullable=False)
    details:Mapped[str]=mapped_column(Text,nullable=False,default='')
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow)

Index('ix_attempt_subject_time',LoginAttempt.subject_hash,LoginAttempt.created_at)
