import os
from pathlib import Path
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from .models import Base

ROOT=Path(__file__).resolve().parent.parent
DATA_DIR=Path(os.getenv('DATA_DIR',str(ROOT/'data')))
DATA_DIR.mkdir(parents=True,exist_ok=True)
UPLOAD_DIR=Path(os.getenv('UPLOAD_DIR',str(DATA_DIR/'uploads')))
UPLOAD_DIR.mkdir(parents=True,exist_ok=True)
DATABASE_URL=os.getenv('DATABASE_URL',f'sqlite:///{DATA_DIR / "pawbridge.db"}')
if DATABASE_URL.startswith('postgres://'):
    DATABASE_URL='postgresql+psycopg://'+DATABASE_URL[len('postgres://'):]
elif DATABASE_URL.startswith('postgresql://'):
    DATABASE_URL='postgresql+psycopg://'+DATABASE_URL[len('postgresql://'):]
engine=create_engine(DATABASE_URL,pool_pre_ping=True,connect_args={'check_same_thread':False,'timeout':30} if DATABASE_URL.startswith('sqlite:') else {})
SessionLocal=sessionmaker(engine,autoflush=False,expire_on_commit=False)

def get_db():
    db=SessionLocal()
    try: yield db
    finally: db.close()

def init_db(): Base.metadata.create_all(engine)

COOKIE_SECURE=os.getenv('COOKIE_SECURE','false').lower()=='true'
APP_ORIGIN=(os.getenv('APP_ORIGIN') or os.getenv('RENDER_EXTERNAL_URL') or '').rstrip('/')
_RENDER_HOSTNAME=os.getenv('RENDER_EXTERNAL_HOSTNAME','')
ALLOWED_HOSTS=[x.strip() for x in os.getenv('ALLOWED_HOSTS',_RENDER_HOSTNAME or '*').split(',') if x.strip()]
IS_PRODUCTION=os.getenv('ENVIRONMENT','development').lower()=='production'
