'use strict';
const form=document.getElementById('loginForm');
form?.addEventListener('submit',async ev=>{
 ev.preventDefault();const btn=document.getElementById('signInButton'),err=document.getElementById('error');
 err.textContent='';btn.disabled=true;btn.textContent='驗證中…';
 try{const res=await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:document.getElementById('email').value.trim(),password:document.getElementById('password').value}),credentials:'same-origin'});
 const data=await res.json();if(!res.ok)throw new Error(typeof data.detail==='string'?data.detail:'登入失敗');window.location.assign('/member');
 }catch(e){err.textContent=e.message;btn.disabled=false;btn.textContent='安全登入 ↗';}
});
