'use strict';
// Authenticated member portal. Every API response is authorized independently by the server.
let ME=null, CSRF='', CURRENT='overview', ORDER_PAGE=1;
let PRODUCTS=[], ORDERS=[], CUSTOMERS=[], USERS=[], ALL_PRODUCTS=[], ALL_ORDERS=[], COMPANY=null;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const n=v=>Number(v||0).toLocaleString('zh-TW');
const money=v=>'NT$ '+(Number(v||0)/100).toLocaleString('zh-TW',{maximumFractionDigits:2});
const empty=t=>`<div class="empty">${esc(t)}</div>`;
const date=s=>s?String(s).replace('T',' ').slice(0,16):'—';
function notify(s,error=false){const el=$('#toast');el.textContent=s;el.className='toast on'+(error?' error':'');setTimeout(()=>{if(el.textContent===s)el.className='toast'},5800)}
async function api(url,opt={}){
 const options={credentials:'same-origin',...opt};options.headers={...(options.body instanceof FormData?{}:{'Content-Type':'application/json'}),...(opt.headers||{})};
 if(options.method && options.method!=='GET')options.headers['X-CSRF-Token']=CSRF;
 const resp=await fetch(url,options);
 let data;try{data=await resp.json()}catch{data={detail:'伺服器暫時無法回應'}}
 if(resp.status===401){window.location.replace('/login');throw Error('登入工作階段已結束')}
 if(!resp.ok)throw Error(typeof data.detail==='string'?data.detail:'資料處理失敗');return data;
}
function post(url,data){return api(url,{method:'POST',body:JSON.stringify(data)})}
function patch(url,data){return api(url,{method:'PATCH',body:JSON.stringify(data)})}
function formv(form){return Object.fromEntries(new FormData(form).entries())}
const dict={'overview':['銷售總覽','商品動態與銷售表現，清晰呈現。'],'products':['我的商品','您的寵物商品與庫存資訊。'],'orders':['銷售訂單','追蹤訂單狀態與商品售出數量。'],'customers':['客戶與會員','建立合作客戶與安全登入帳號。'],'manage-products':['商品管理','建立商品、設定價格及上傳實拍照片。'],'manage-orders':['訂單管理','正式建立訂單並同步銷售記錄。'],'company':['公司歷程與公益','以可查核的資料記錄企業進程與動物關懷。'],'audit':['操作紀錄','查閱管理員近期資料異動。'],'settings':['帳號安全','保護您的企業與會員資料。']};
function go(view){if(!dict[view])return;if(!ME)return;if(ME.role!=='admin'&&['customers','manage-products','manage-orders','company','audit'].includes(view))return;
 CURRENT=view;$$('.view').forEach(e=>e.classList.toggle('visible',e.dataset.view===view));$$('.nav-link[data-go]').forEach(e=>e.classList.toggle('active',e.dataset.go===view));
 $('#pageTitle').textContent=dict[view][0];$('#crumb').textContent=dict[view][0];$('#pageDesc').textContent=dict[view][1];$('#sidebar').classList.remove('open');
 if(view==='customers'||view==='manage-products'||view==='manage-orders'||view==='company'||view==='audit')refreshAdmin().catch(e=>notify(e.message,true));
 if(view==='orders')refreshOrders().catch(e=>notify(e.message,true));window.scrollTo({top:0,behavior:'smooth'});
}
function status(s){return `<span class="status ${esc(s)}">${esc(s)}</span>`}
function rowTable(head,rows){return rows.length?`<div class="table-wrap"><table class="data-table"><thead><tr>${head.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`:empty('尚無相關資料。')}
function ordersHtml(orders){return rowTable(['訂單編號','商品名稱','數量','銷售金額','訂單狀態','建立時間'],orders.map(o=>`<tr><td><strong>${esc(o.order_no)}</strong></td><td>${esc(o.product_name)}</td><td>${n(o.quantity)} 件</td><td>${money(o.total_cents)}</td><td>${status(o.status)}</td><td>${date(o.created_at)}</td></tr>`))}
function renderProducts(){
 $('#productSummary').textContent=`共 ${n(PRODUCTS.length)} 項商品`;
 $('#productCards').innerHTML=PRODUCTS.length?PRODUCTS.map(p=>`<article class="product-card"><img src="${esc(p.image_url)}" alt="${esc(p.name)}" loading="lazy"><div class="prod-content"><small>${esc(p.category)} · ${esc(p.sku)}</small><h3>${esc(p.name)}</h3><div class="prod-meta"><span>${p.active?'展示中':'已停用'}</span><span>庫存 ${n(p.stock)} 件</span></div><div class="price">${money(p.price_cents)}</div></div></article>`).join(''):empty('您的商品尚未建立。請聯繫企業管理員新增商品與照片。');
}
function renderOverview(d){
 const entries=[['▧','已建立商品',d.products,'項'],['▤','累計訂單',d.orders,'筆'],['◈','累計售出',d.sold_quantity,'件'],['NT$','已付款銷售總額',money(d.sales_cents),'']];
 $('#metrics').innerHTML=entries.map(([ico,label,val,unit])=>`<div class="metric"><div class="icon">${ico}</div><small>${esc(label)}</small><strong>${typeof val==='number'?n(val):esc(val)}</strong><span class="unit">${esc(unit)}</span></div>`).join('');
 $('#pendingCount').textContent=n(d.pending_orders);$('#productCount').textContent=n(d.products);
 const max=Math.max(1,...d.monthly_sales.map(x=>x.amount_cents));
 $('#salesChart').innerHTML=d.monthly_sales.map(x=>`<div class="bar-wrapper"><b>${money(x.amount_cents)}</b><div class="bar" style="height:${Math.max(3,Math.round(166*x.amount_cents/max))}px"></div><small>${esc(x.month.slice(5))} 月</small></div>`).join('');
 $('#recentOrders').innerHTML=ordersHtml(ORDERS.slice(0,5));
}
async function refreshOrders(){const d=await api('/api/orders?page='+ORDER_PAGE);ORDERS=d.items;
 $('#ordersTotal').textContent=`共 ${n(d.total)} 筆`;$('#orderPage').textContent=`第 ${ORDER_PAGE} 頁`;
 $('#prevOrders').disabled=ORDER_PAGE===1;$('#nextOrders').disabled=ORDER_PAGE*50>=d.total;
 $('#orderTable').innerHTML=ordersHtml(ORDERS);return d;
}
async function refresh(){const [pr,db]=await Promise.all([api('/api/products'),api('/api/dashboard')]);PRODUCTS=pr.items;
 await refreshOrders();renderProducts();renderOverview(db);
 $('#syncTime').textContent='資料已更新 · '+new Date().toLocaleTimeString('zh-TW',{hour:'2-digit',minute:'2-digit'});
}
function options(items,field='name'){return items.map(v=>`<option value="${esc(v.id)}">${esc(v[field]||v.id)}</option>`).join('')}
function renderAdmin(){
 const dropdown=`<option value="">請選擇客戶</option>`+options(CUSTOMERS);
 $$('.customer-select').forEach(sel=>{const val=sel.value;sel.innerHTML=dropdown;if(val)sel.value=val});
 $('#customerList').innerHTML=CUSTOMERS.length?CUSTOMERS.map(c=>`<div class="list-item"><div><strong>${esc(c.name)}</strong><small>代碼：${esc(c.code)} · ID ${c.id}</small></div></div>`).join(''):empty('尚未建立合作客戶');
 $('#memberList').innerHTML=USERS.length?USERS.map(u=>`<div class="list-item"><div><strong>${esc(u.name)} ${u.role==='admin'?'（管理員）':''}</strong><small>${esc(u.email)} · ${esc(CUSTOMERS.find(c=>c.id===u.customer_id)?.name||'企業管理員')} · ${u.active?'啟用中':'已停用'}</small></div>${u.role==='member'?`<div class="list-actions"><button type="button" class="mini-btn" data-act="toggle-member" data-id="${u.id}" data-active="${u.active?'false':'true'}">${u.active?'停用帳號':'重新啟用'}</button><button type="button" class="mini-btn" data-act="reset-member" data-id="${u.id}">重設密碼</button></div>`:''}</div>`).join(''):empty('目前只有初始管理員');
 $('#manageProductList').innerHTML=ALL_PRODUCTS.length?ALL_PRODUCTS.map(p=>`<div class="list-item"><img class="admin-photo" src="${esc(p.image_url)}" alt="${esc(p.name)}"><div style="flex:1"><strong>${esc(p.name)}</strong><small>${esc(p.sku)} · ${esc(CUSTOMERS.find(c=>c.id===p.customer_id)?.name||'')} · 庫存 ${n(p.stock)} · ${money(p.price_cents)}</small></div><div class="list-actions"><label class="mini-btn">更換照片<input type="file" accept="image/png,image/jpeg,image/webp" data-upload="${p.id}" style="display:none"></label><button class="mini-btn" data-act="toggle-product" data-id="${p.id}" data-active="${p.active?'false':'true'}">${p.active?'停用商品':'啟用商品'}</button></div></div>`).join(''):empty('尚無商品');
 const customerId=Number($('#orderCustomer').value);
 $('#orderProduct').innerHTML='<option value="">請選擇商品</option>'+options(ALL_PRODUCTS.filter(p=>p.customer_id===customerId&&p.active),'name');
 $('#manageOrdersList').innerHTML=ALL_ORDERS.length?ALL_ORDERS.map(o=>`<div class="list-item"><div><strong>${esc(o.order_no)} · ${esc(o.product_name)}</strong><small>${esc(CUSTOMERS.find(c=>c.id===o.customer_id)?.name||'')} · ${n(o.quantity)} 件 · ${money(o.total_cents)} · ${date(o.created_at)}</small></div><div class="list-actions"><select data-status="${o.id}">${['待付款','已付款','配送中','已完成','已取消','已退款'].map(s=>`<option ${o.status===s?'selected':''}>${esc(s)}</option>`).join('')}</select><button class="mini-btn" data-act="save-status" data-id="${o.id}">更新狀態</button></div></div>`).join(''):empty('尚未建立訂單');
 if(COMPANY){const items=[...COMPANY.timeline.map(x=>({...x,type:'歷程',detail:x.title})),...COMPANY.donations.map(x=>({...x,type:'公益',detail:x.recipient}))];
 $('#companyItems').innerHTML=items.length?items.sort((a,b)=>b.date.localeCompare(a.date)).map(x=>`<div class="list-item"><div><strong>${esc(x.date)} · ${esc(x.type)}：${esc(x.detail)}</strong><small>${esc(x.description||'')} · ${x.published?'已公開':'草稿'} ${x.evidence_url?'· 有證明連結':''}</small></div><button class="mini-btn" data-act="publish" data-type="${x.type==='歷程'?'timeline':'donations'}" data-id="${x.id}" data-publish="${!x.published}">${x.published?'下架':'公開'}</button></div>`).join(''):empty('尚無公司歷程與公益紀錄')}
}
async function refreshAdmin(){if(ME.role!=='admin')return;
 const [cs,us,pr,od,co,au]=await Promise.all([api('/api/admin/customers'),api('/api/admin/users'),api('/api/products'),api('/api/orders'),api('/api/admin/company'),api('/api/admin/audit')]);
 CUSTOMERS=cs.items;USERS=us.items;ALL_PRODUCTS=pr.items;ALL_ORDERS=od.items;COMPANY=co;
 renderAdmin();$('#auditList').innerHTML=au.items.length?au.items.map(x=>`<div class="list-item"><div><strong>${esc(x.action)} · ${esc(x.target)}</strong><small>${date(x.date)} ${esc(x.details||'')}</small></div></div>`).join(''):empty('目前沒有操作紀錄');
}
function bindForm(id,fn){$(id).addEventListener('submit',async ev=>{ev.preventDefault();const btn=ev.target.querySelector('[type=submit]');btn.disabled=true;
 try{await fn(ev.target);ev.target.reset();notify('資料已成功儲存');await refresh();if(ME.role==='admin')await refreshAdmin()}catch(e){notify(e.message,true)}finally{btn.disabled=false}
})}
async function init(){
 try{ME=await api('/api/me');CSRF=ME.csrf_token;$('#currentUser').textContent=ME.name;
 if(ME.role==='admin')$$('.admin-only').forEach(el=>el.hidden=false);
 $('#dashboardApp').hidden=false;$('#loading').remove();await refresh();
 }catch(e){$('#loading').textContent='會員驗證失敗，請返回登入頁。';if(!String(e.message).includes('登入工作階段'))location.replace('/login');return}
 $$('[data-go]').forEach(btn=>btn.addEventListener('click',()=>go(btn.dataset.go)));
 $$('[data-link]').forEach(btn=>btn.addEventListener('click',e=>{e.preventDefault();go(btn.dataset.link)}));
 $('#menuToggle').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
 $('#refreshData').addEventListener('click',()=>refresh().then(()=>notify('資料已更新')).catch(e=>notify(e.message,true)));
 $('#prevOrders').addEventListener('click',()=>{ORDER_PAGE--;refreshOrders().catch(e=>notify(e.message,true))});
 $('#nextOrders').addEventListener('click',()=>{ORDER_PAGE++;refreshOrders().catch(e=>notify(e.message,true))});
 $('#signOut').addEventListener('click',async()=>{try{await api('/api/auth/logout',{method:'POST'})}finally{location.assign('/login')}});
 bindForm('#changePassword',f=>post('/api/auth/change-password',formv(f)));
 if(ME.role==='admin'){
   bindForm('#addCustomer',f=>post('/api/admin/customers',formv(f)));
   bindForm('#addMember',f=>{const p=formv(f);p.customer_id=Number(p.customer_id);return post('/api/admin/users',p)});
   bindForm('#addProduct',f=>{const p=formv(f);p.customer_id=Number(p.customer_id);p.price_cents=Math.round(Number(p.price)*100);p.stock=Number(p.stock);delete p.price;return post('/api/admin/products',p)});
   bindForm('#addOrder',f=>{const p=formv(f);p.customer_id=Number(p.customer_id);p.product_id=Number(p.product_id);p.quantity=Number(p.quantity);return post('/api/admin/orders',p)});
   bindForm('#addTimeline',f=>{const p=formv(f);p.published=f.elements.published.checked;return post('/api/admin/timeline',p)});
   bindForm('#addDonation',f=>{const p=formv(f);p.published=f.elements.published.checked;p.amount_cents=p.amount===''?null:Math.round(Number(p.amount)*100);delete p.amount;return post('/api/admin/donations',p)});
   $('#orderCustomer').addEventListener('change',()=>{const id=Number($('#orderCustomer').value);$('#orderProduct').innerHTML='<option value="">請選擇商品</option>'+options(ALL_PRODUCTS.filter(p=>p.customer_id===id&&p.active),'name')});
   document.addEventListener('change',async ev=>{if(!ev.target.matches('[data-upload]'))return;const id=ev.target.dataset.upload;const file=ev.target.files[0];if(!file)return;
     try{const fd=new FormData();fd.append('file',file);await api(`/api/admin/products/${id}/image`,{method:'POST',body:fd});notify('商品照片上傳成功');await refreshAdmin();await refresh()}catch(e){notify(e.message,true)}
   });
   document.addEventListener('click',async ev=>{const el=ev.target.closest('[data-act]');if(!el)return;const id=Number(el.dataset.id);try{
     if(el.dataset.act==='toggle-member')await patch(`/api/admin/users/${id}`,{active:el.dataset.active==='true'});
     if(el.dataset.act==='reset-member'){const v=prompt('請輸入至少 12 個字元的新密碼（請勿在公開場合分享）');if(!v)return;if(v.length<12)throw Error('密碼至少 12 字元');await patch(`/api/admin/users/${id}`,{new_password:v})}
     if(el.dataset.act==='toggle-product')await patch(`/api/admin/products/${id}`,{active:el.dataset.active==='true'});
     if(el.dataset.act==='save-status')await patch(`/api/admin/orders/${id}`,{status:document.querySelector(`[data-status="${id}"]`).value});
     if(el.dataset.act==='publish')await patch(`/api/admin/${el.dataset.type}/${id}/publish`,{published:el.dataset.publish==='true'});
     notify('更新成功');await refreshAdmin();await refresh();
   }catch(e){notify(e.message,true)}});
 }
 window.setInterval(()=>{if(!document.hidden)refresh().catch(()=>{})},30000);
}
init();
