'use strict';
const nav=document.getElementById('mainNav'),toggle=document.getElementById('mobileToggle');
toggle?.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open))});
nav?.querySelectorAll('a').forEach(x=>x.addEventListener('click',()=>{nav.classList.remove('open');toggle.setAttribute('aria-expanded','false')}));
const escapeHtml=(s)=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
fetch('/api/public/company').then(r=>r.json()).then(data=>{
 const t=document.getElementById('timelineList');
 t.innerHTML=data.timeline?.length?data.timeline.map(x=>`<div class="timeline-item"><strong>${escapeHtml(x.date)} · ${escapeHtml(x.title)}</strong><p>${escapeHtml(x.description)}</p></div>`).join(''):'<div class="timeline-item"><strong>公司歷程籌備中</strong><p>正式的里程碑及公司故事會在完成資料核實後公布。</p></div>';
 const d=document.getElementById('donationList');
 d.innerHTML=data.donations?.length?data.donations.map(x=>`<div class="donation-item"><strong>${escapeHtml(x.date)} · ${escapeHtml(x.recipient)}</strong><p>${escapeHtml(x.description)}</p><p>${x.amount_cents===null?'物資或非金錢支持':'捐贈紀錄：NT$ '+Math.round(x.amount_cents/100).toLocaleString('zh-TW')}</p><a href="${escapeHtml(x.evidence_url)}" target="_blank" rel="noreferrer noopener">檢視捐贈證明 ↗</a></div>`).join(''):'<div class="donation-item"><strong>愛心行動持續規劃中</strong><p>這裡僅會公開能提供證明的實際公益紀錄。</p></div>';
}).catch(()=>{});
