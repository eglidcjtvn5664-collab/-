from bs4 import BeautifulSoup
from pathlib import Path
root=Path(__file__).parent
src=BeautifulSoup(Path('/mnt/data/pawbridge-premium/index.html').read_text(encoding='utf-8'),'html.parser')
public=src.find(id='public')
for img in public.find_all('img'):
    if (img.get('src') or '').startswith('assets/'):
        img['src']='/static/'+img['src']
for el in public.find_all(attrs={'data-action':'login'}):
    a=src.new_tag('a',href='/login')
    a['class']=el.get('class',[])
    a.string=el.get_text(' ',strip=True)
    el.replace_with(a)
# Clear placeholder company copy: placeholder is explicitly labeled, not a registered legal entity.
for el in public.select('small'):
    if '示範品牌' in el.get_text():el.string='寵物選品・國際貿易'
for p in public.select('.pill'):
    if '後台管理示範' in p.get_text():p.string='公司歷程 / 依實際紀錄公開'
for p in public.find_all(string=True):
    if '展示版' in str(p):
        p.replace_with(str(p).replace('展示版','官網').replace('網站視覺使用 AI 生成','網站目前使用 AI 生成'))
for el in public.select('#publicContactForm'):
    el.clear()
    el.append(src.new_tag('h3'))
    el.h3.string='合作洽詢'
    p=src.new_tag('p')
    p.string='此區為聯絡資料預留位置。正式公司信箱與客服管道確認後即可開通詢問表單。'
    el.append(p)
    x=src.new_tag('p');x['class']='note';x.string='目前未啟用表單提交，避免您的資料寄送到未確認的地址。'
    el.append(x)
page=BeautifulSoup('<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#17352c"><meta name="description" content="PAWBRIDGE 寵物用品國際貿易與會員商品銷售平台。"><title>PAWBRIDGE｜寵物用品國際貿易</title></head><body></body></html>','html.parser')
style=src.find('style')
(root/'app/static/site.css').write_text(style.text,encoding='utf-8')
css=page.new_tag('link',rel='stylesheet',href='/static/site.css')
page.head.append(css)
page.body.append(public)
new=page.new_tag('script',src='/static/site.js',defer=True)
page.body.append(new)
(root/'app/templates/index.html').write_text(str(page),encoding='utf-8')
